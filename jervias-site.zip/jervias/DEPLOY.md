# Jervias Music & Movies: Jinsi ya Kui-deploy na Kuiongoza

## 1. Muundo wa folda

```
jervias/
  index.html        <- website nzima (HTML + CSS + JS)
  assets/
    bg1.jpg bg2.jpg bg3.jpg   <- picha za background
    pwani-sunrise.mp3, ...   <- (hiari) muziki wako kwa download ya uhakika
```

Kufungua kwenye kompyuta: bonyeza mara mbili `index.html`. Hakuna kitu cha kuinstall.

## 2. Deploy BURE (dakika 3, njia rahisi zaidi): Netlify Drop

1. Fungua https://app.netlify.com/drop
2. Buruta folda ya `jervias` ndani ya ukurasa.
3. Utapata link kama `https://jina-lolote.netlify.app` papo hapo.
4. Kubadilisha jina: Site configuration > Change site name > `jervias` (inakuwa `jervias.netlify.app` kama halijachukuliwa).
5. Kusasisha baadaye: Deploys > buruta folda mpya.

Njia mbadala zisizo na gharama: Cloudflare Pages, GitHub Pages (weka `index.html` kwenye repo kisha Settings > Pages), Vercel.

## 3. Domain yako mwenyewe (mfano jervias.co.tz au jervias.com)

1. Nunua domain kwa registrar: `.com` kwa Namecheap/Cloudflare/GoDaddy (takriban $10-15 kwa mwaka), `.co.tz` kupitia msajili aliyeidhinishwa na TZNIC (tznic.or.tz).
2. Netlify: Domain management > Add custom domain > andika domain yako.
3. Kwenye registrar weka DNS ulizopewa na Netlify (rekodi ya `A` au `CNAME`, au tumia nameservers zao).
4. Subiri dakika chache hadi saa 24. HTTPS (SSL) inawashwa bure kiotomatiki.

## 4. Kuweka trailer za YouTube

Kila movie/tamthilia kwenye `index.html` ina sehemu `yt:''`. Weka ID ya video:

Link `https://www.youtube.com/watch?v=AbCdEfGhIjK` -> ID ni `AbCdEfGhIjK`

```js
{id:'f1', type:'movie', title:'Mji wa Dhahabu', year:2025, genre:'Action', hue:40, yt:'AbCdEfGhIjK'},
```

Njia ya haraka bila kuhariri code: bonyeza Play kwenye kadi, bandika link ya YouTube kwenye kisanduku, bonyeza WEKA TRAILER. (Inahifadhiwa kwenye kifaa chako tu, haionekani kwa wageni wengine.)

Tumia trailer zilizopakiwa na channel rasmi za wenye haki. Video zikizuia embedding, YouTube itaonyesha kosa; chagua video nyingine.

## 5. Kuweka muziki wako na kuwezesha Download

1. Weka mp3 kwenye `assets/`, mfano `assets/pwani-sunrise.mp3`.
2. Badilisha `src` ya wimbo: `src:'assets/pwani-sunrise.mp3'`.
3. Download inafanya kazi vizuri zaidi faili likiwa kwenye tovuti yako mwenyewe (same origin). Tumia muziki wako mwenyewe, uliopewa ruhusa, au wenye leseni huru (Creative Commons, public domain).

Nyimbo za SoundHelix zilizopo ni za majaribio tu.

## 6. Picha za background (motion)

Background ni picha 3 (`assets/bg1.jpg`, `bg2.jpg`, `bg3.jpg`) zinazobadilishana kila sekunde 7 kwa crossfade, na zinasogea polepole (zoom/pan) pamoja na cheche za dhahabu. Kubadilisha picha: weka picha mpya zenye majina hayo hayo kwenye `assets/`. Ongeza picha ya nne kwa kunakili mstari wa `<div class="slide" ...>` kwenye `index.html`.

Folda ya `assets/` LAZIMA iende pamoja na `index.html` unapo-deploy, vinginevyo background haitaonekana.

Kumbuka: picha zina watu halisi. Hakikisha una ruhusa yao kabla ya kuweka website hadharani. Usitumie clip za Marvel/Iron Man kwa kuwa zina hakimiliki.

## 7. Kubadilisha maudhui

Kila kitu kiko kwenye array ya `ITEMS` ndani ya `<script>`. Ongeza kipengee kipya kwa kunakili mstari mmoja na kubadilisha `id` (lazima iwe ya kipekee), `title`, `year`, `genre`, na `yt` au `src`. Posters zinatengenezwa kiotomatiki; `hue` (0-360) inabadilisha rangi.

Kubadilisha movie kubwa ya hero: badilisha `FEATURED_ID`.

## 8. Maelezo ya kisheria (kumbuka)

- Hakuna kupakua video/muziki kutoka YouTube.
- Hakuna kupandisha movie au muziki wenye hakimiliki bila ruhusa.
- Embed rasmi za YouTube na faili zako au za leseni huru ndizo salama.
